package com.EdutechAsistencia.asistencia;


import com.EdutechAsistencia.asistencia.Controller.AsistenciaController;
import com.EdutechAsistencia.asistencia.Model.AsistenciaModel;
import com.EdutechAsistencia.asistencia.Service.AsistenciaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.datafaker.Faker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(AsistenciaController.class)
public class AsistenciaControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AsistenciaService asistenciaService;

    @Autowired
    private ObjectMapper objectMapper;

    private Faker faker;

    @BeforeEach
    void setUp() {
        faker = new Faker(new Locale("es"));
    }


    private AsistenciaModel generarAsistenciaFalsa() {
        AsistenciaModel asistencia = new AsistenciaModel();
        asistencia.setId(faker.number().randomNumber());
        asistencia.setRun(faker.idNumber().valid());
        asistencia.setNombre(faker.name().firstName());
        asistencia.setApellido(faker.name().lastName());
        asistencia.setFechaAsistencia(new Date());
        asistencia.setVecesAsistido(String.valueOf(faker.number().numberBetween(1, 10)));
        return asistencia;
    }


    @Test
    void testListarAsistencias() throws Exception {

        List<AsistenciaModel> lista = Arrays.asList(generarAsistenciaFalsa(), generarAsistenciaFalsa());
        Mockito.when(asistenciaService.findall()).thenReturn(lista);

        try {
            mockMvc.perform(get("/api/v1/asistencia"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(lista.size()));
            System.out.println("Testeo de 'LISTAR ASISTENCIA' ejecutado con Exito");
        } catch (Exception e) {
            System.out.println("Fallo en 'LISTAR ASISTENCIA' " + e.getMessage());
            throw e;
        }
    }


    @Test
    void testBuscarAsistenciaPorId() throws Exception {

        AsistenciaModel asistencia = generarAsistenciaFalsa();
        Mockito.when(asistenciaService.findById(asistencia.getId())).thenReturn(asistencia);

        try {
            mockMvc.perform(get("/api/v1/asistencia/{id}", asistencia.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.run").value(asistencia.getRun()));
            System.out.println("Testeo de 'BUSCAR ASISTENCIA POR ID' ejecutado con Exito");
        } catch (Exception e) {
            System.out.println("Fallo en 'BUSCAR ASISTENCIA POR ID' " + e.getMessage());
            throw e;
        }
    }


    @Test
    void testGuardarAsistencia() throws Exception {

        AsistenciaModel asistencia = generarAsistenciaFalsa();
        Mockito.when(asistenciaService.save(Mockito.any(AsistenciaModel.class))).thenReturn(asistencia);

        try {
            mockMvc.perform(post("/api/v1/asistencia")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(asistencia)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.run").value(asistencia.getRun()));
            System.out.println("Testeo de 'GUARDAR ASISTENCIA' ejecutado con Exito");
        } catch (Exception e) {
            System.out.println("Fallo en 'GUARDAR ASISTENCIA' " + e.getMessage());
            throw e;
        }
    }


    @Test
    void testActualizarAsistencia() throws Exception {

        AsistenciaModel existente = generarAsistenciaFalsa();
        AsistenciaModel actualizada = generarAsistenciaFalsa();
        actualizada.setId(existente.getId());

        Mockito.when(asistenciaService.findById(existente.getId())).thenReturn(existente);
        Mockito.when(asistenciaService.save(Mockito.any(AsistenciaModel.class))).thenReturn(actualizada);

        try {
            mockMvc.perform(put("/api/v1/asistencia/{id}", existente.getId())

                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualizada)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.run").value(actualizada.getRun()));
            System.out.println("Testeo de 'ACTUALIZAR ASISTENCIA' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en 'ACTUALIZAR ASISTENCIA' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testEliminarAsistencia() throws Exception {

        AsistenciaModel asistencia = generarAsistenciaFalsa();
        Mockito.doNothing().when(asistenciaService).delete(asistencia.getId());

        try {
            mockMvc.perform(delete("/api/v1/asistencia/{id}", asistencia.getId()))
                .andExpect(status().isNoContent());
            System.out.println("Testeo de 'ELIMINAR ASISTENCIA' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en 'ELIMINAR ASISTENCIA' " + e.getMessage());
            throw e;
        }
    }
}


