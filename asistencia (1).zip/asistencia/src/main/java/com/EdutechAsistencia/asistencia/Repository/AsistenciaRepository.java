package com.EdutechAsistencia.asistencia.Repository;

import com.EdutechAsistencia.asistencia.Model.AsistenciaModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AsistenciaRepository extends JpaRepository<AsistenciaModel, Long>{

}