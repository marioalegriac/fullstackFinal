package com.EdutechAsistencia.asistencia.Controller;

import com.EdutechAsistencia.asistencia.Model.AsistenciaModel;
import com.EdutechAsistencia.asistencia.Service.AsistenciaService;
import com.EdutechAsistencia.asistencia.hateoas.AsistenciaModelAssembler;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

// http://localhost:8084/api/v1/asistencia url para postman
// url swagger http://localhost:8084/swagger-ui/index.html

@RestController
@RequestMapping("/api/v1/asistencia")
public class AsistenciaController {

    @Autowired
    public AsistenciaService asistenciaService;

    @Autowired
    private AsistenciaModelAssembler assembler;

    @GetMapping
    @Operation(summary = "Mostrar todas las asistencias", description = "Mostrar todas las asistencias")
    public ResponseEntity<CollectionModel<EntityModel<AsistenciaModel>>> listar() {
        List<AsistenciaModel> lista = asistenciaService.findall();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<EntityModel<AsistenciaModel>> asistenciaModels = lista.stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return ResponseEntity.ok(
                CollectionModel.of(asistenciaModels,
                        linkTo(methodOn(AsistenciaController.class).listar()).withSelfRel()));

    }
    
    @PostMapping
    @Operation(summary = "Crear asistencia", description = "Crear asistencia")
    public ResponseEntity<EntityModel<AsistenciaModel>> guardar(@RequestBody AsistenciaModel asistencia) {
        AsistenciaModel nueva = asistenciaService.save(asistencia);
        EntityModel<AsistenciaModel> model = assembler.toModel(nueva);
        return ResponseEntity.created(model.getRequiredLink("self").toUri()).body(model);
    }


    @GetMapping("/{id}")
    @Operation(summary = "Mostrar asistencia", description = "Mostrar asistencias por su ID")
    public ResponseEntity<EntityModel<AsistenciaModel>> buscar(@PathVariable Long id) {
        try {
            AsistenciaModel asistencia = asistenciaService.findById(id);
            return ResponseEntity.ok(assembler.toModel(asistencia));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/{id}")
    @Operation(summary = "Actualizar asistencia", description = "Actualizar asistencia por su ID")
    public ResponseEntity<EntityModel<AsistenciaModel>> actualizar(@PathVariable Long id, @RequestBody AsistenciaModel asistencia) {
        try {
            AsistenciaModel existente = asistenciaService.findById(id);
            existente.setRun(asistencia.getRun());
            existente.setNombre(asistencia.getNombre());
            existente.setApellido(asistencia.getApellido());
            existente.setFechaAsistencia(asistencia.getFechaAsistencia());
            existente.setVecesAsistido(asistencia.getVecesAsistido());

            AsistenciaModel actualizado = asistenciaService.save(existente);
            return ResponseEntity.ok(assembler.toModel(actualizado));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar asistencia", description = "Eliminar asistencia por su ID")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        try {
            asistenciaService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
  


}
