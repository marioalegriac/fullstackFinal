package com.EdutechAsistencia.asistencia.hateoas;

import com.EdutechAsistencia.asistencia.Controller.AsistenciaController;
import com.EdutechAsistencia.asistencia.Model.AsistenciaModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;


import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class AsistenciaModelAssembler implements RepresentationModelAssembler<AsistenciaModel, EntityModel<AsistenciaModel>> {

    @Override
    public EntityModel<AsistenciaModel> toModel(AsistenciaModel asistencia) {
        return EntityModel.of(asistencia,
                linkTo(methodOn(AsistenciaController.class).buscar(asistencia.getId())).withSelfRel(),
                linkTo(methodOn(AsistenciaController.class).listar()).withRel("asistencias"),
                linkTo(methodOn(AsistenciaController.class).actualizar(asistencia.getId(), asistencia)).withRel("actualizar"),
                linkTo(methodOn(AsistenciaController.class).eliminar(asistencia.getId())).withRel("eliminar")
        );
    }
}