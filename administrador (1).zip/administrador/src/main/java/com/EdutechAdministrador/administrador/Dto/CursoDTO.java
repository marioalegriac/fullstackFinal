package com.EdutechAdministrador.administrador.Dto;

import lombok.Data;
import java.util.List;

@Data
public class CursoDTO {

    public Long id;
    public String nombre;
    public String descripcion;
    public Integer duracionHoras;
    public List<Long> clienteIds;

}
