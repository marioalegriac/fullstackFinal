package com.EdutechAdministrador.administrador.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;


@Configuration
public class AdministradorConfig {
    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }

}
