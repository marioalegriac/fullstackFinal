package com.EdutechAdministrador.administrador.hateoas;

import com.EdutechAdministrador.administrador.Controller.AdministradorController;
import com.EdutechAdministrador.administrador.Dto.CursoDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class CursoModelAssembler implements RepresentationModelAssembler<CursoDTO, EntityModel<CursoDTO>> {

    @Override
    public EntityModel<CursoDTO> toModel(CursoDTO curso) {
        return EntityModel.of(curso,
                linkTo(methodOn(AdministradorController.class).obtenerCursosDelCliente(curso.getId())).withRel("cursos-cliente"));
    }
}
