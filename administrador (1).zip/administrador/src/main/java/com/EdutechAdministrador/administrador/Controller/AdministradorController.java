package com.EdutechAdministrador.administrador.Controller;

import com.EdutechAdministrador.administrador.Dto.ClienteDTO;
import com.EdutechAdministrador.administrador.Dto.CursoDTO;
import com.EdutechAdministrador.administrador.Model.AdministradorModel;
import com.EdutechAdministrador.administrador.Service.AdministradorService;
import com.EdutechAdministrador.administrador.hateoas.AdministradorModelAssembler;
import com.EdutechAdministrador.administrador.hateoas.ClienteModelAssembler;
import com.EdutechAdministrador.administrador.hateoas.CursoModelAssembler;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;


// url postman http://localhost:8082/api/v2/administradores
// url swagger http://localhost:8082/swagger-ui.html


@RestController
@RequestMapping("/api/v2/administradores")
public class AdministradorController {

    private final AdministradorService service;
    private final AdministradorModelAssembler administradorAssembler;
    private final ClienteModelAssembler clienteAssembler;
    private final CursoModelAssembler cursoAssembler;

    @Autowired
    public AdministradorController(AdministradorService service,
                                  AdministradorModelAssembler administradorAssembler,
                                  ClienteModelAssembler clienteAssembler,
                                  CursoModelAssembler cursoAssembler) {
        this.service = service;
        this.administradorAssembler = administradorAssembler;
        this.clienteAssembler = clienteAssembler;
        this.cursoAssembler = cursoAssembler;
    }

    @GetMapping
    @Operation(summary = "Mostrar todos los admin", description = "Mostrar todos los admins")
    public CollectionModel<EntityModel<AdministradorModel>> listar() {
        List<EntityModel<AdministradorModel>> admins = service.obtenerTodos().stream()
                .map(administradorAssembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(admins,
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AdministradorController.class).listar()).withSelfRel());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Mostrar admin", description = "Mostrar a un admin por su ID")
    public EntityModel<AdministradorModel> obtenerPorId(@PathVariable Long id) {
        return service.obtenerPorId(id)
                .map(administradorAssembler::toModel)
                .orElseThrow(() -> new RuntimeException("Administrador no encontrado: " + id));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar admin", description = "Eliminar a un admin por su ID")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/cursos/{cursoId}/clientes")
    @Operation(summary = "Obtener cliente de un curso", description = "Obtener todos los clientes de un curso")
    public CollectionModel<EntityModel<ClienteDTO>> obtenerClienteDeCurso(@PathVariable Long cursoId) {
        List<EntityModel<ClienteDTO>> clientes = service.obtenerClientesDeCurso(cursoId).stream()
                .map(clienteAssembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(clientes,
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AdministradorController.class).obtenerClienteDeCurso(cursoId)).withSelfRel());
    }

    @GetMapping("/clientes/{clienteId}/cursos")
    @Operation(summary = "Obtener cursos de un cliente", description = "Mostrar todos los cursos de un cliente")
    public CollectionModel<EntityModel<CursoDTO>> obtenerCursosDelCliente(@PathVariable Long clienteId) {
        List<EntityModel<CursoDTO>> cursos = service.obtenerCursosDelCliente(clienteId).stream()
                .map(cursoAssembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(cursos,
                WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AdministradorController.class).obtenerCursosDelCliente(clienteId)).withSelfRel());
    }

    @PostMapping
    @Operation(summary = "Crear admin", description = "Crear administrador")
    public ResponseEntity<EntityModel<AdministradorModel>> crearAdministrador(@RequestBody AdministradorModel administrador) {
        AdministradorModel nuevoAdmin = service.guardar(administrador);
        EntityModel<AdministradorModel> entityModel = administradorAssembler.toModel(nuevoAdmin);

        return ResponseEntity
                .created(entityModel.getRequiredLink(IanaLinkRelations.SELF).toUri())
                .body(entityModel);
    }

    @DeleteMapping("/cursos/{cursoId}/clientes/{clienteId}")
    @Operation(summary = "Eliminar cliente de curso", description = "Eliminar un cliente de un curso")
    public ResponseEntity<Void> eliminarClienteDeCurso(@PathVariable Long cursoId, @PathVariable Long clienteId) {
        boolean eliminado = service.eliminarClienteDeCurso(cursoId, clienteId);
        if (eliminado) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/{id}")
    @Operation(summary = "Actualizar admin", description = "Actualizar datos de administrador")
    public ResponseEntity<EntityModel<AdministradorModel>> actualizar(@PathVariable Long id, @RequestBody AdministradorModel adminActualizado) {
        return service.obtenerPorId(id)
                .map(adminExistente -> {
                    adminExistente.setNombre(adminActualizado.getNombre());
                    adminExistente.setApellido(adminActualizado.getApellido());
                    adminExistente.setPassword(adminActualizado.getPassword());
                    adminExistente.setCorreo(adminActualizado.getCorreo());
                    AdministradorModel actualizado = service.guardar(adminExistente);
                    EntityModel<AdministradorModel> entityModel = administradorAssembler.toModel(actualizado);
                    return ResponseEntity.ok(entityModel);
                })
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

        
}
