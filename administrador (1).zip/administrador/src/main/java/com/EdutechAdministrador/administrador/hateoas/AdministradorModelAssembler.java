package com.EdutechAdministrador.administrador.hateoas;

import com.EdutechAdministrador.administrador.Controller.AdministradorController;
import com.EdutechAdministrador.administrador.Model.AdministradorModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class AdministradorModelAssembler implements RepresentationModelAssembler<AdministradorModel, EntityModel<AdministradorModel>> {

    @Override
    public EntityModel<AdministradorModel> toModel(AdministradorModel admin) {
        return EntityModel.of(admin,
                linkTo(methodOn(AdministradorController.class).obtenerPorId(admin.getId())).withSelfRel(),
                linkTo(methodOn(AdministradorController.class).listar()).withRel("administradores"),
                linkTo(methodOn(AdministradorController.class).eliminar(admin.getId())).withRel("eliminar"),
                linkTo(methodOn(AdministradorController.class).actualizar(admin.getId(), admin)).withRel("actualizar")
        );
    }
}