package com.EdutechAdministrador.administrador.hateoas;

import com.EdutechAdministrador.administrador.Controller.AdministradorController;
import com.EdutechAdministrador.administrador.Dto.ClienteDTO;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class ClienteModelAssembler implements RepresentationModelAssembler<ClienteDTO, EntityModel<ClienteDTO>> {

    @Override
    public EntityModel<ClienteDTO> toModel(ClienteDTO cliente) {
        return EntityModel.of(cliente,
                linkTo(methodOn(AdministradorController.class).obtenerClienteDeCurso(cliente.getId())).withRel("cliente-curso"));
    }
}