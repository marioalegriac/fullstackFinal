package com.EdutechAdministrador.administrador.Service;

import com.EdutechAdministrador.administrador.Dto.ClienteDTO;
import com.EdutechAdministrador.administrador.Dto.CursoDTO;
import com.EdutechAdministrador.administrador.Model.AdministradorModel;
import com.EdutechAdministrador.administrador.Repository.AdministradorRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Arrays;

@Service
public class AdministradorService {
    
    public final RestTemplate restTemplate;
    public final AdministradorRepository repository;

    public final String CURSO_URL = "http://localhost:8081/api/v1/cursos";
    public final String CLIENTE_URL = "http://localhost:8080/api/v1/clientes";

    public AdministradorService(AdministradorRepository repository, RestTemplate restTemplate){
        this.repository = repository;
        this.restTemplate = restTemplate;
    }    
    

    public List<AdministradorModel> obtenerTodos(){
        return repository.findAll();
    }
    

    public Optional<AdministradorModel> obtenerPorId(Long id){
        return repository.findById(id);
    }

    public AdministradorModel guardar(AdministradorModel admin){
        return repository.save(admin);
    }

    public void eliminar(Long id){
        repository.deleteById(id);
    }

    public List<ClienteDTO> obtenerClientesDeCurso(Long cursoId){
        CursoDTO curso = restTemplate.getForObject(CURSO_URL + "/" + cursoId, CursoDTO.class);
        if(curso == null || curso.getClienteIds() == null ){
            return List.of();
        }
        return curso.getClienteIds().stream()
            .map(id -> restTemplate.getForObject(CLIENTE_URL + "/" + id, ClienteDTO.class))
            .collect(Collectors.toList());
    }
    
    
    public List<CursoDTO> obtenerCursosDelCliente(Long clienteId){
        CursoDTO[] cursos = restTemplate.getForObject(CURSO_URL, CursoDTO[].class);

        if(cursos == null){
            return List.of();
        }
        return Arrays.stream(cursos)
            .filter(curso -> curso.getClienteIds()!=null && curso.getClienteIds().contains(clienteId))
            .collect(Collectors.toList());
    }


    public boolean eliminarClienteDeCurso(Long cursoId, long clienteId){
        String url = CURSO_URL + "/" + cursoId + "/clientes/" + clienteId;
        try{
            restTemplate.delete(url);
            return true;
        }catch (Exception e){
            return false;
        }
    }

}
