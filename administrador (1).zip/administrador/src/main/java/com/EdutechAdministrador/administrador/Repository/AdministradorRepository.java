package com.EdutechAdministrador.administrador.Repository;

import com.EdutechAdministrador.administrador.Model.AdministradorModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdministradorRepository extends JpaRepository <AdministradorModel, Long>{

}
