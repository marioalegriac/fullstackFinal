package com.EdutechAdministrador.administrador.controller;


import com.EdutechAdministrador.administrador.Model.AdministradorModel;
import com.EdutechAdministrador.administrador.Service.AdministradorService;
import com.EdutechAdministrador.administrador.Controller.AdministradorController;
import com.EdutechAdministrador.administrador.Dto.ClienteDTO;
import com.EdutechAdministrador.administrador.Dto.CursoDTO;
import net.datafaker.Faker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// para usar algunos metodos debes tener cliente y curso corriendo con sus objetos creados

@WebMvcTest(AdministradorController.class)
public class AdministradorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private AdministradorService administradorService;

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final Faker faker = new Faker();
    private AdministradorModel admin;


    @BeforeEach
    void setup() {
        admin = AdministradorModel.builder()
            .id(1L)
            .run(faker.idNumber().valid())
            .nombre(faker.name().firstName())
            .apellido(faker.name().lastName())
            .correo(faker.internet().emailAddress())
            .password(faker.internet().password(8, 16, true, true))
            .fechaNacimiento(faker.date().birthday())
            .build();
    }

    @Test
    void TestListar() throws Exception {
        
        List<AdministradorModel> lista = List.of(admin);
        Mockito.when(administradorService.obtenerTodos()).thenReturn(lista);

        try {
            mockMvc.perform(get("/api/v2/administradores"))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'LISTAR' ejecutado con exito ");
        } catch (Exception e) {
            System.out.println("Fallo en el test de 'LISTAR' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void TestObtenerPorId() throws Exception {

        Mockito.when(administradorService.obtenerPorId(1L)).thenReturn(Optional.of(admin));

        try {
            mockMvc.perform(get("/api/v2/administradores/1"))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'OBTENER POR ID' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test de 'OBTENER POR ID' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void TestCrearAdministrador() throws Exception {

        Mockito.when(administradorService.guardar(Mockito.any())).thenReturn(admin);

        try {
            mockMvc.perform(post("/api/v2/administradores")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(admin)))
                .andExpect(status().isCreated());
            System.out.println("Testeo de 'CREAR ADMINISTRADOR' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test de 'CREAR ADMINISTRADOR' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void TestEliminarAdministrador() throws Exception {
    

        Mockito.when(administradorService.obtenerPorId(admin.getId())).thenReturn(Optional.of(admin));
        Mockito.doNothing().when(administradorService).eliminar(admin.getId());

        try {
            mockMvc.perform(delete("/api/v2/administradores/{id}", admin.getId()))
                    .andExpect(status().isNoContent());
                System.out.println("Testeo de 'ELIMINAR ADMINISTRADOR' ejecutado con exito");
        } catch (AssertionError | Exception e) {
            System.out.println("Fallo en el testeo de 'ELIMINAR ADMINISTRADOR': " + e.getMessage());
            throw e;
        }
    }

    @Test
    void TestActualizarAdministrador() throws Exception {

        AdministradorModel actualizado = admin;

        actualizado.setNombre(faker.name().firstName());

        Mockito.when(administradorService.obtenerPorId(1L)).thenReturn(Optional.of(admin));
        Mockito.when(administradorService.guardar(Mockito.any())).thenReturn(actualizado);

        try {
            mockMvc.perform(put("/api/v2/administradores/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualizado)))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'ACTUALIZAR ADMINISTRADOR' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test de 'ACTUALIZAR ADMINISTRADOR' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testObtenerClientesDeCurso() throws Exception {

        ClienteDTO cliente = new ClienteDTO();
        cliente.setId(1L);
        cliente.setNombre(faker.name().firstName());
        cliente.setApellido(faker.name().lastName());
        cliente.setCorreo(faker.internet().emailAddress());

        Mockito.when(administradorService.obtenerClientesDeCurso(1L))
            .thenReturn(List.of(cliente));

        try {
            mockMvc.perform(get("/api/v2/administradores/cursos/1/clientes"))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'OBTENER CLIENTES DE CURSO' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test de 'OBTENER CLIENTES DE CURSO' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testObtenerCursosDelCliente() throws Exception {

        CursoDTO curso = new CursoDTO();
        curso.setId(1L);
        curso.setNombre("fullstack I");
        curso.setClienteIds(List.of(1L));

        Mockito.when(administradorService.obtenerCursosDelCliente(1L))
            .thenReturn(List.of(curso));

        try {
            mockMvc.perform(get("/api/v2/administradores/clientes/1/cursos"))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'OBTENER CURSOS DEL CLIENTE' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test de 'OBTENER CURSOS DEL CLIENTE' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testEliminarClienteDeCurso() throws Exception {

        Mockito.when(administradorService.eliminarClienteDeCurso(1L, 1L)).thenReturn(true);

        try {
            mockMvc.perform(delete("/api/v2/administradores/cursos/1/clientes/1"))
                .andExpect(status().isNoContent());
            System.out.println("Testeo de 'ELIMINAR CLIENTE DE CURSO' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test de 'ELIMINAR CLIENTE DE CURSO' " + e.getMessage());
            throw e;
        }
    }
}


