package com.pagos.cl.pagos.controller;

import com.pagos.cl.pagos.hateoas.PagosModelAssembler;
import com.pagos.cl.pagos.model.Pagos;
import com.pagos.cl.pagos.service.PagosService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;


// url postman http://localhost:8085/api/v1/pagos
// url swagger http://localhost:8085/swagger-ui/index.html


@RestController
@RequestMapping("/api/v1/pagos")
public class PagosController {

    @Autowired
    private PagosService pagosService;

    @Autowired
    private PagosModelAssembler assembler;

    @GetMapping
    @Operation(summary = "Mostrar todos los pagos", description = "Mostrar todos los pagos creados")
    public ResponseEntity<CollectionModel<EntityModel<Pagos>>> listar() {

        List<Pagos> pagos = pagosService.findAll();

        if (pagos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }


        List<EntityModel<Pagos>> pagosModel = pagos.stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());


        return ResponseEntity.ok(
                CollectionModel.of(pagosModel,
                        linkTo(methodOn(PagosController.class).listar()).withSelfRel()));

    }

    @GetMapping("/{id}")
    @Operation(summary = "Mostrar un pago", description = "Mostrar un pago por su ID")
    public ResponseEntity<EntityModel<Pagos>> buscar(@PathVariable Integer id) {
        try {
            Pagos pago = pagosService.findById(id);
            return ResponseEntity.ok(assembler.toModel(pago));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @Operation(summary = "Crear pago", description = "Crear un pago")
    public ResponseEntity<EntityModel<Pagos>> guardar(@RequestBody Pagos pagos) {
        Pagos nuevoPago = pagosService.save(pagos);
        EntityModel<Pagos> pagoModel = assembler.toModel(nuevoPago);
        return ResponseEntity.created(pagoModel.getRequiredLink("self").toUri()).body(pagoModel);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un pago", description = "Actualizar un pago por su ID")
    public ResponseEntity<EntityModel<Pagos>> actualizar(@PathVariable Integer id, @RequestBody Pagos pagos) {

        try {
            Pagos pagoExistente = pagosService.findById(id);
            pagoExistente.setMonto(pagos.getMonto());
            pagoExistente.setFechapago(pagos.getFechapago());
            pagoExistente.setMetodoPago(pagos.getMetodoPago());
            pagoExistente.setDescripcion(pagos.getDescripcion());

            Pagos actualizado = pagosService.save(pagoExistente);
            return ResponseEntity.ok(assembler.toModel(actualizado));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar pago", description = "Eliminar un pago por su ID")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        try {
            pagosService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

}