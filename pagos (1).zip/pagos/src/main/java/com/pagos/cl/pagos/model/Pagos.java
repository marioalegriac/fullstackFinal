package com.pagos.cl.pagos.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Table(name="pagos")
@Data 
@NoArgsConstructor
@AllArgsConstructor
public class Pagos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Integer id;


    @Column(nullable=false)
    public Double monto;

    @Column(nullable=false)
    @Temporal(TemporalType.DATE)
    public Date fechapago;

    @Column(nullable=false)
    public String metodoPago;

    @Column(nullable=false)
    public String descripcion;
}