package com.pagos.cl.pagos.service;

import com.pagos.cl.pagos.model.Pagos;
import com.pagos.cl.pagos.repository.PagosRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class PagosService {

    @Autowired
    public PagosRepository pagosRepository;

    public List<Pagos> findAll(){
        return pagosRepository.findAll();
    }

    public Pagos findById(Integer id){
        Optional<Pagos> pagoOptional = pagosRepository.findById(id);
        return pagoOptional.orElse(null);
    }

    public Pagos save(Pagos pagos){
        return pagosRepository.save(pagos);
    }

    public void delete(Integer id){
        pagosRepository.deleteById(id);
    }
}