package com.pagos.cl.pagos.hateoas;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.pagos.cl.pagos.controller.PagosController;
import com.pagos.cl.pagos.model.Pagos;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

@Component
public class PagosModelAssembler implements RepresentationModelAssembler<Pagos, EntityModel<Pagos>> {

    
    @Override
    public EntityModel<Pagos> toModel(Pagos pago) {
        return EntityModel.of(pago,
            linkTo(methodOn(PagosController.class).buscar(pago.getId())).withSelfRel(),
            linkTo(methodOn(PagosController.class).listar()).withRel("todos-los-pagos")
        );
    }
}
