package com.pagos.cl.pagos;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pagos.cl.pagos.controller.PagosController;
import com.pagos.cl.pagos.model.Pagos;
import com.pagos.cl.pagos.service.PagosService;
import net.datafaker.Faker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


@WebMvcTest(PagosController.class)
public class PagosControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PagosService pagosService;

    @Autowired
    private ObjectMapper objectMapper;

    private Faker faker;

    @BeforeEach
    void setup() {
        faker = new Faker(new Locale("es"));
    }

    private Pagos generarPagoFake() {
        Pagos pago = new Pagos();
        pago.setId(faker.number().randomDigitNotZero());
        pago.setMonto(faker.number().randomDouble(2, 1000, 10000));
        pago.setFechapago(new Date());
        pago.setMetodoPago(faker.business().creditCardType());
        pago.setDescripcion(faker.lorem().sentence(4));
        return pago;
    }

    @Test
    void testListarPagos() throws Exception {
        List<Pagos> pagos = Arrays.asList(generarPagoFake(), generarPagoFake());
        Mockito.when(pagosService.findAll()).thenReturn(pagos);

        try {
            mockMvc.perform(get("/api/v1/pagos"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.length()").value(pagos.size()));
            System.out.println("Testeo de 'LISTAR PAGOS' ejecutado con exito");
        } catch (AssertionError | Exception e) {
            System.out.println("Fallo en el testeo de 'LISTAR PAGOS': " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testBuscarPagoPorId() throws Exception {
        Pagos pago = generarPagoFake();
        Mockito.when(pagosService.findById(pago.getId())).thenReturn(pago);

        try {
            mockMvc.perform(get("/api/v1/pagos/{id}", pago.getId()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.id").value(pago.getId()));
            System.out.println("Testeo de 'BUSCAR PAGO POR ID' ejecutado con exito");
        } catch (AssertionError | Exception e) {
            System.out.println("Fallo en el testeo de 'BUSCAR PAGO POR ID': " + e.getMessage());
            throw e;

        }
    }

    @Test
    void testCrearPago() throws Exception {
        Pagos pago = generarPagoFake();
        Mockito.when(pagosService.save(Mockito.any(Pagos.class))).thenReturn(pago);


        try {
            mockMvc.perform(post("/api/v1/pagos")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(pago)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.descripcion").value(pago.getDescripcion()));
            System.out.println("Testeo de 'CREAR PAGO' ejecutado con exito");
        } catch (AssertionError | Exception e) {
            System.out.println("Fallo en el testeo de 'CREAR PAGO': " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testActualizarPago() throws Exception {
        Pagos pagoExistente = generarPagoFake();
        Pagos pagoActualizado = generarPagoFake();
        pagoActualizado.setId(pagoExistente.getId());

        Mockito.when(pagosService.findById(pagoExistente.getId())).thenReturn(pagoExistente);
        Mockito.when(pagosService.save(Mockito.any(Pagos.class))).thenReturn(pagoActualizado);

        try {
            mockMvc.perform(put("/api/v1/pagos/{id}", pagoExistente.getId())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(pagoActualizado)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.descripcion").value(pagoActualizado.getDescripcion()));

            System.out.println("Testeo de 'ACTUALIZAR PAGO' ejecutado con exito");
        } catch (AssertionError | Exception e) {
            System.out.println("Fallo en el testeo de 'ACTUALIZAR PAGO': " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testEliminarPago() throws Exception {

        Pagos pago = generarPagoFake();
        Mockito.doNothing().when(pagosService).delete(pago.getId());

        try {
            mockMvc.perform(delete("/api/v1/pagos/{id}", pago.getId()))
                    .andExpect(status().isNoContent());
            System.out.println("Testeo de 'ELIMINAR PAGO' ejecutado con exito");
        } catch (AssertionError | Exception e) {
            System.out.println("Fallo en el testeo de 'ELIMINAR PAGO': " + e.getMessage());
            throw e;
        }
    }
}