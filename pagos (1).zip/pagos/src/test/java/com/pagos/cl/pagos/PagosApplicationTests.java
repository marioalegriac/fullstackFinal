package com.pagos.cl.pagos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PagosApplicationTests {

	@Test
	void contextLoads() {
	}

}
