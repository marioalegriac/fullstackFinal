package com.EductechCliente.cl.cliente.controller;

import com.EductechCliente.cl.cliente.model.Cliente;
import com.EductechCliente.cl.cliente.service.ClienteService;
import com.EductechCliente.cl.cliente.hateoas.ClienteModelAssembler;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


// url postman http://localhost:8080/api/v1/clientes
// url swagger http://localhost:8080/swagger-ui/index.html

@RestController
@RequestMapping("/api/v1/clientes")
public class ClienteController {

    @Autowired
    public ClienteService clienteService;

    @Autowired
    private ClienteModelAssembler assembler;


    @GetMapping
    @Operation(summary = "Mostrar clientes", description = "Mostrar todos los clientes creados")
    public ResponseEntity<CollectionModel<EntityModel<Cliente>>> listar() {
        List<Cliente> clientes = clienteService.findAll();
        if (clientes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<EntityModel<Cliente>> modelos = clientes.stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return ResponseEntity.ok(CollectionModel.of(modelos,
                linkTo(methodOn(ClienteController.class).listar()).withSelfRel()));
    }

    @PostMapping
    @Operation(summary = "Crear cliente", description = "Crear un cliente")
    public ResponseEntity<EntityModel<Cliente>> guardar(@RequestBody Cliente cliente) {
        Cliente nuevo = clienteService.save(cliente);
        EntityModel<Cliente> model = assembler.toModel(nuevo);
        return ResponseEntity.created(model.getRequiredLink("self").toUri()).body(model);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Mostrar un cliente", description = "Buscar un cliente por su ID")
    public ResponseEntity<EntityModel<Cliente>> buscar(@PathVariable Integer id) {
        try {
            Cliente cliente = clienteService.findById(id);
            return ResponseEntity.ok(assembler.toModel(cliente));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar cliente", description = "Actualizar datos de un cliente por su ID")
    public ResponseEntity<EntityModel<Cliente>> actualizar(@PathVariable Integer id, @RequestBody Cliente cliente) {
        try {
            Cliente existente = clienteService.findById(id);
            existente.setRun(cliente.getRun());
            existente.setNombre(cliente.getNombre());
            existente.setApellido(cliente.getApellido());
            existente.setFechaNacimiento(cliente.getFechaNacimiento());
            existente.setCorreo(cliente.getCorreo());

            Cliente actualizado = clienteService.save(existente);
            return ResponseEntity.ok(assembler.toModel(actualizado));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar cliente", description = "Eliminar un cliente por su ID")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        try {
            clienteService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
          
}
