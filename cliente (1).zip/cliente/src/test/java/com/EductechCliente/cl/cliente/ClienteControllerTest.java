package com.EductechCliente.cl.cliente;

import com.EductechCliente.cl.cliente.controller.ClienteController;
import com.EductechCliente.cl.cliente.model.Cliente;
import com.EductechCliente.cl.cliente.service.ClienteService;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.datafaker.Faker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;



@WebMvcTest(ClienteController.class)
public class ClienteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ClienteService clienteService;

    @Autowired
    private ObjectMapper objectMapper;

    private Faker faker;

    @BeforeEach
    void setup() {
        faker = new Faker(new Locale("es"));
    }

    private Cliente generarClienteFake() {
        Cliente cliente = new Cliente();
        cliente.setId(faker.number().numberBetween(1, 1000));
        cliente.setRun(faker.idNumber().valid());
        cliente.setNombre(faker.name().firstName());
        cliente.setApellido(faker.name().lastName());
        cliente.setFechaNacimiento(faker.date().birthday());
        cliente.setCorreo(faker.internet().emailAddress());
        return cliente;
    }

    @Test
    void testListarClientes() throws Exception {

        try{
            List<Cliente> clientes = List.of(generarClienteFake(), generarClienteFake());

            Mockito.when(clienteService.findAll()).thenReturn(clientes);

            mockMvc.perform(get("/api/v1/clientes"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.length()").value(clientes.size()));
                
            System.out.println("Testeo de 'LISTAR CLIENTES' ejecutado con exito");
        }catch (Exception e){
            System.out.println("Fallo en el testeo de 'LISTAR CLIENTES'" + e.getMessage());
            throw e;
        }

            
    }

    @Test
    void testGuardarCliente() throws Exception {

        Cliente cliente = generarClienteFake();

        Mockito.when(clienteService.save(Mockito.any(Cliente.class))).thenReturn(cliente);

        try{
            mockMvc.perform(post("/api/v1/clientes")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(cliente)))
                    .andExpect(status().isCreated())
                    .andExpect(jsonPath("$.nombre").value(cliente.getNombre()));
            System.out.println("Testeo de 'GUARDAR CLIENTE' ejecutado con exito");
        }catch(Exception e){
            System.out.println("Fallo en el testeo de 'GUARDAR CLIENTE' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testBuscarClientePorId() throws Exception {

        Cliente cliente = generarClienteFake();

        Mockito.when(clienteService.findById(cliente.getId())).thenReturn(cliente);

        try{
            mockMvc.perform(get("/api/v1/clientes/{id}", cliente.getId()))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.nombre").value(cliente.getNombre()));
            System.out.println("Testeo de 'BUSCAR CLIENTE POR ID' ejecutado con exito");
        }catch(Exception e){
            System.out.println("Fallo en el testeo de 'BUSCAR CLIENTE POR ID' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testActualizarCliente() throws Exception {

        Cliente clienteExistente = generarClienteFake();
        Cliente clienteActualizado = generarClienteFake();
        clienteActualizado.setId(clienteExistente.getId());

        Mockito.when(clienteService.findById(clienteExistente.getId())).thenReturn(clienteExistente);
        Mockito.when(clienteService.save(Mockito.any(Cliente.class))).thenReturn(clienteActualizado);

        try{
            mockMvc.perform(put("/api/v1/clientes/{id}", clienteExistente.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(clienteActualizado)))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$.correo").value(clienteActualizado.getCorreo()));
            System.out.println("Testeo de 'ACTUALIZAR CLIENTE' ejecutado con exito");
        }catch(Exception e){
            System.out.println("Fallo en el testeo de 'ACTUALIZAR CLIENTE' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testEliminarCliente() throws Exception {

        Long id = 1L;

        Mockito.doNothing().when(clienteService).delete(id);

        try{
            mockMvc.perform(delete("/api/v1/clientes/{id}", id))
                    .andExpect(status().isNoContent());
            System.out.println("Testeo de 'ELIMINAR CLIENTE' ejecutado con exito");
        }catch(Exception e){
            System.out.println("Fallo en el testeo de 'ELIMINAR CLIENTE' " + e.getMessage());
            throw e;
        }
    }
}

