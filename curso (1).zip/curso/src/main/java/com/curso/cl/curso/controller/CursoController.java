package com.curso.cl.curso.controller;

import com.curso.cl.curso.model.CursoModel;
import com.curso.cl.curso.service.CursoService;
import com.curso.cl.curso.hateoas.CursoModelAssembler;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


// url postman http://localhost:8081/api/v1/cursos
// link para swagger http://localhost:8081/swagger-ui/index.html


@RestController
@RequestMapping("/api/v1/cursos")
public class CursoController {

    @Autowired
    public CursoService cursoService;

    @Autowired
    private CursoModelAssembler assembler;


    @GetMapping
    @Operation(summary = "Obtener todos los cursos", description = "Obtener todos los cursos")
    public ResponseEntity<CollectionModel<EntityModel<CursoModel>>> obtenerTodosLosCursos() {
        List<CursoModel> cursos = cursoService.findAll();

        if (cursos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<EntityModel<CursoModel>> cursoModels = cursos.stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return ResponseEntity.ok(CollectionModel.of(cursoModels,
                linkTo(methodOn(CursoController.class).obtenerTodosLosCursos()).withSelfRel()));
    }


    @GetMapping("/{id}")
    @Operation(summary = "Buscar curso", description = "Buscar curso por su ID")
    public ResponseEntity<EntityModel<CursoModel>> buscar(@PathVariable Long id) {
        Optional<CursoModel> curso = cursoService.findById(id);
        return curso.map(value -> ResponseEntity.ok(assembler.toModel(value)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Crear curso", description = "Crear curso")
    public ResponseEntity<EntityModel<CursoModel>> crear(@RequestBody CursoModel curso) {
        CursoModel nuevoCurso = cursoService.save(curso);
        EntityModel<CursoModel> model = assembler.toModel(nuevoCurso);
        return ResponseEntity.created(model.getRequiredLink("self").toUri()).body(model);
    }


    @PutMapping("/{id}")
    @Operation(summary = "Actualizar curso", description = "Actualizar curso por su ID")
    public ResponseEntity<EntityModel<CursoModel>> actualizar(@PathVariable Long id, @RequestBody CursoModel curso) {
        Optional<CursoModel> existente = cursoService.findById(id);

        if (existente.isPresent()) {
            CursoModel actualizado = existente.get();
            actualizado.setNombre(curso.getNombre());
            actualizado.setDescripcion(curso.getDescripcion());
            actualizado.setDuracionHoras(curso.getDuracionHoras());

            CursoModel resultado = cursoService.save(actualizado);
            return ResponseEntity.ok(assembler.toModel(resultado));
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar curso", description = "Eliminar curso por su ID")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (cursoService.findById(id).isPresent()) {
            cursoService.delete(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{cursoId}/clientes/{clienteId}")
    @Operation(summary = "Eliminar cliente de curso", description = "Eliminar un cliente de un curso")
    public ResponseEntity<Void> eliminarClienteDeCurso(
            @PathVariable Long cursoId,
            @PathVariable Long clienteId) {

        boolean eliminado = cursoService.eliminarClienteDeCurso(cursoId, clienteId);
        if (!eliminado) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }
    


    @PostMapping("/{cursoId}/clientes/{clienteId}")
    @Operation(summary = "Agregar cliente a curso", description = "Agregar cliente a un curso")
    public ResponseEntity<String> agregarClienteACurso(
            @PathVariable Long cursoId,
            @PathVariable Long clienteId) {

        boolean agregado = cursoService.agregarClienteACurso(cursoId, clienteId);
        if (!agregado) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok("Cliente agregado con éxito");
    }
    

}


    
    
    
    
    


