package com.curso.cl.curso.service;

public @interface Transactional {

}
