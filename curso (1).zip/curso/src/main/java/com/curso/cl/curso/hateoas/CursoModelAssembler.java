package com.curso.cl.curso.hateoas;

import com.curso.cl.curso.controller.CursoController;
import com.curso.cl.curso.model.CursoModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class CursoModelAssembler implements RepresentationModelAssembler<CursoModel, EntityModel<CursoModel>> {

    @Override
    public EntityModel<CursoModel> toModel(CursoModel curso) {
        return EntityModel.of(curso,
                linkTo(methodOn(CursoController.class).buscar(curso.getId())).withSelfRel(),
                linkTo(methodOn(CursoController.class).obtenerTodosLosCursos()).withRel("cursos"));
    }
}