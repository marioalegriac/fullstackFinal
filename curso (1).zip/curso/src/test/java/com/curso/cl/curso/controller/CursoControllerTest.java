package com.curso.cl.curso.controller;

import com.curso.cl.curso.model.CursoModel;
import com.curso.cl.curso.service.CursoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.datafaker.Faker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.*;

import javax.print.attribute.standard.Media;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CursoController.class)
public class CursoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CursoService cursoService;

    @Autowired
    private ObjectMapper objectMapper;

    private Faker faker;

    @BeforeEach
    void setup() {
        faker = new Faker(new Locale("es"));
    }

    private CursoModel generarCursoFake() {
        CursoModel curso = new CursoModel();
        curso.setId(faker.number().randomNumber());
        curso.setNombre(faker.educator().course());
        curso.setDescripcion(faker.lorem().sentence(5));
        curso.setDuracionHoras(faker.number().numberBetween(10, 100));
        curso.setClienteIds(new ArrayList<>());
        return curso;
        
    }

    @Test
    void testObtenerTodosLosCursos() throws Exception {

        List<CursoModel> cursos = Arrays.asList(
            generarCursoFake(),
            generarCursoFake()
        );

        Mockito.when(cursoService.findAll()).thenReturn(cursos);

        try{
            mockMvc.perform(get("/api/v1/cursos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(cursos.size()));
            System.out.println("Testeo de 'OBTENER TODOS LOS CURSOS' ejecutado con exito");
        }catch(AssertionError | Exception e ){
            System.out.println("Fallo en el test de 'OBTENER TODOS LOS CURSOS'" + e.getMessage());
            throw e;
        }
    }

    @Test
    void testBuscarCursoPorId() throws Exception {

        CursoModel curso = generarCursoFake();

        Mockito.when(cursoService.findById(curso.getId())).thenReturn(Optional.of(curso));

        try{
            mockMvc.perform(get("/api/v1/cursos/{id}", curso.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value(curso.getNombre()));
            System.out.println("Testeo de 'BUSCAR CURSO POR ID' ejecutado con exito");
        }catch (AssertionError | Exception e){
            System.out.println("Fallo en el test de 'BUSCAR CURSO POR ID'" + e.getMessage());
            throw e;
        }
    }

    @Test
    void testCrearCurso() throws Exception {

        CursoModel curso = generarCursoFake();

        Mockito.when(cursoService.save(Mockito.any(CursoModel.class))).thenReturn(curso);

        try {
            mockMvc.perform(post("/api/v1/cursos")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(curso)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.nombre").value(curso.getNombre()));

            System.out.println("Testeo de 'CREAR CURSO' ejecutado con exito");
        
        }catch (AssertionError | Exception e){
            System.out.println("Fallo en el test de CREAR CURSO" + e.getMessage());
            throw e;
        }
    }

    @Test
    void testActualizarCurso() throws Exception {

        CursoModel cursoExistente = generarCursoFake();
        CursoModel cursoActualizado = generarCursoFake();

        Mockito.when(cursoService.findById(cursoExistente.getId())).thenReturn(Optional.of(cursoExistente));
        Mockito.when(cursoService.save(Mockito.any(CursoModel.class))).thenReturn(cursoActualizado);

        try{
            mockMvc.perform(put("/api/v1/cursos/{id}", cursoExistente.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(cursoActualizado)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value(cursoActualizado.getNombre()));
            System.out.println("Testeo de 'ACTUALIZAR CURSO' ejecutado con exito");
        }catch (AssertionError | Exception e){
            System.out.println("Fallo en el testeo de 'ACTUALIZAR CURSO'" + e.getMessage());
            throw e;
        }
    }

    @Test
    void testEliminarCurso() throws Exception {
        
        CursoModel curso = generarCursoFake();

        Mockito.when(cursoService.findById(curso.getId())).thenReturn(Optional.of(curso));
        Mockito.doNothing().when(cursoService).delete(curso.getId());

        try{
            mockMvc.perform(delete("/api/v1/cursos/{id}", curso.getId()))
                .andExpect(status().isNoContent());
            System.out.println("Testeo de 'ELIMINAR CURSO'  ejecutado con exito");
        }catch (AssertionError | Exception e){
            System.out.println("Fallo en el testeo de 'ELIMINAR CURSO' " + e.getMessage());
            throw e;

        }
    }

    @Test
    void testAgregarClienteACurso() throws Exception {
        Long cursoId = 1L;
        Long clienteId = 2L;

        Mockito.when(cursoService.agregarClienteACurso(cursoId, clienteId)).thenReturn(true);

        try{
            mockMvc.perform(post("/api/v1/cursos/{cursoId}/clientes/{clienteId}", cursoId, clienteId))
                .andExpect(status().isOk())
                .andExpect(content().string("Cliente agregado con exito"));
            System.out.println("Testeo de 'AGREGAR CLIENTE A CURSO' ejecutado con exito ");
        }catch (AssertionError | Exception e){
            System.out.println("Fallo en el testeo de 'AGREGAR CLIENTE A CURSO' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testEliminarClienteDeCurso() throws Exception {
        Long cursoId = 1L;
        Long clienteId = 2L;

        Mockito.when(cursoService.eliminarClienteDeCurso(cursoId, clienteId)).thenReturn(true);

        try{
            mockMvc.perform(delete("/api/v1/cursos/{cursoId}/clientes/{clienteId}", cursoId, clienteId))
                .andExpect(status().isNoContent());
            System.out.println("Testeo de 'ELIMINAR CLIENTE DE CURSO' ejecutado con exito");
        }catch (AssertionError | Exception e){
            System.out.println("Fallo en el testeo de 'ELIMINAR CLIENTE DE CURSO' " + e.getMessage());
            throw e;

        }
    }
}
