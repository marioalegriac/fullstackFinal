package com.Edutechsoporte.soporte.controller;


import com.Edutechsoporte.soporte.Model.SoporteModel;
import com.Edutechsoporte.soporte.Service.SoporteService;
import com.Edutechsoporte.soporte.Controller.SoporteController;
import com.Edutechsoporte.soporte.Dto.ClienteDTO;
import net.datafaker.Faker;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// Para usar algunos metodos debes tener creado cliente


@WebMvcTest(SoporteController.class)
public class SoporteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private RestTemplate restTemplate;

    @MockBean
    private SoporteService soporteService;

    private final Faker faker = new Faker();
    private final ObjectMapper objectMapper = new ObjectMapper();

    private SoporteModel soporte;

    @BeforeEach
    void setup() {
        soporte = SoporteModel.builder()
                .id(1L)
                .run(faker.idNumber().valid())
                .nombre(faker.name().firstName())
                .apellido(faker.name().lastName())
                .correo(faker.internet().emailAddress())
                .fechaNacimiento(faker.date().birthday())
                .build();
    }

    @Test
    void testCrearSoporte() throws Exception {

        Mockito.when(soporteService.guardar(Mockito.any(SoporteModel.class))).thenReturn(soporte);

        try {
            mockMvc.perform(post("/api/v1/soportes")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(soporte)))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'CREAR SOPORTE' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test 'CREAR SOPORTE' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testListarSoportes() throws Exception {

        List<SoporteModel> soporteList = List.of(soporte);
        Mockito.when(soporteService.listar()).thenReturn(soporteList);

        try {
            mockMvc.perform(get("/api/v1/soportes"))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$[0].id").value(soporte.getId()))
                    .andExpect(jsonPath("$[0].run").value(soporte.getRun()))
                    .andExpect(jsonPath("$[0].nombre").value(soporte.getNombre()))
                    .andExpect(jsonPath("$[0].apellido").value(soporte.getApellido()))
                    .andExpect(jsonPath("$[0].correo").value(soporte.getCorreo()));
                System.out.println("Testeo de 'LISTAR SOPORTES' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test 'LISTAR SOPORTES' " + e.getMessage());
            throw e;
        }
    }


    @Test
    void testObtenerSoportePorId() throws Exception {

        Mockito.when(soporteService.obtenerPorId(1L)).thenReturn(Optional.of(soporte));

        try {
            mockMvc.perform(get("/api/v1/soportes/1"))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'OBTENER POR ID' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test 'OBTENER POR ID' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testActualizarSoporte() throws Exception {

        SoporteModel actualizado = soporte;
        actualizado.setNombre(faker.name().firstName());

        Mockito.when(soporteService.obtenerPorId(1L)).thenReturn(Optional.of(soporte));
        Mockito.when(soporteService.guardar(Mockito.any(SoporteModel.class))).thenReturn(actualizado);

        try {
            mockMvc.perform(put("/api/v1/soportes/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualizado)))
                .andExpect(status().isOk());
            System.out.println("Testeo de 'ACTUALIZAR SOPORTE' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en test 'ACTUALIZAR SOPORTE' " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testEliminarSoporte() throws Exception {

        Mockito.when(soporteService.existePorId(1L)).thenReturn(true);
        Mockito.doNothing().when(soporteService).eliminarPorId(1L);

        try {
            mockMvc.perform(delete("/api/v1/soportes/1"))
                .andExpect(status().isNoContent());
            System.out.println("Testeo de 'ELIMINAR SOPORTE' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test 'ELIMINAR SOPORTE': " + e.getMessage());
            throw e;
        }
    }

    @Test
    void testObtenerClientePorId() throws Exception {
    
        ClienteDTO clienteDTO = new ClienteDTO();
        clienteDTO.setNombre(faker.name().firstName());
        clienteDTO.setApellido(faker.name().lastName());
        clienteDTO.setCorreo(faker.internet().emailAddress());

        Mockito.when(soporteService.obtenerClientePorId(1)).thenReturn(clienteDTO);

        try {
            mockMvc.perform(get("/api/v1/soportes/cliente/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value(clienteDTO.getNombre()))
                .andExpect(jsonPath("$.apellido").value(clienteDTO.getApellido()))
                .andExpect(jsonPath("$.correo").value(clienteDTO.getCorreo()));
            System.out.println("Testeo de 'OBTENER CLIENTE POR ID' ejecutado con exito");
        } catch (Exception e) {
            System.out.println("Fallo en el test 'OBTENER CLIENTE POR ID' " + e.getMessage());
            throw e;
        }
    }

}

