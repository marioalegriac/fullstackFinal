package com.Edutechsoporte.soporte.Controller;

import com.Edutechsoporte.soporte.Dto.ClienteDTO;
import com.Edutechsoporte.soporte.Model.SoporteModel;
import com.Edutechsoporte.soporte.Service.SoporteService;
import com.Edutechsoporte.soporte.hateoas.SoporteModelAssembler;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;


// url postman http://localhost:8083/api/v1/soportes
//url swagger http://localhost:8083/swagger-ui/index.html


@RestController
@RequestMapping("/api/v1/soportes")
public class SoporteController {

    @Autowired
    private SoporteService soporteService;

    @Autowired
    private SoporteModelAssembler assembler;

    @PostMapping
    @Operation(summary = "Crear soporte", description = "Crear un soporte")
    public ResponseEntity<EntityModel<SoporteModel>> crear(@RequestBody SoporteModel soporte) {
        SoporteModel nuevo = soporteService.guardar(soporte);
        EntityModel<SoporteModel> model = assembler.toModel(nuevo);
        return ResponseEntity.created(model.getRequiredLink("self").toUri()).body(model);
    }

    @GetMapping
    @Operation(summary = "Mostrar todos los soportes", description = "Mostrar todos los soportes existentes")
    public ResponseEntity<CollectionModel<EntityModel<SoporteModel>>> listar() {
        List<SoporteModel> lista = soporteService.listar();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        List<EntityModel<SoporteModel>> soporteModels = lista.stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return ResponseEntity.ok(CollectionModel.of(soporteModels,
                linkTo(methodOn(SoporteController.class).listar()).withSelfRel()));

    }

    @GetMapping("/{id}")
    @Operation(summary = "Mostrar soporte", description = "Mostrar un soporte por su ID")
    public ResponseEntity<EntityModel<SoporteModel>> obtener(@PathVariable Long id) {
        Optional<SoporteModel> soporte = soporteService.obtenerPorId(id);
        return soporte.map(s -> ResponseEntity.ok(assembler.toModel(s)))
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar soporte", description = "Actualizar un soporte por su ID")
    public ResponseEntity<EntityModel<SoporteModel>> actualizarSoporte(@PathVariable Long id, @RequestBody SoporteModel soporteActualizado) {
        Optional<SoporteModel> soporteExistente = soporteService.obtenerPorId(id);

        if (soporteExistente.isPresent()) {
            SoporteModel soporte = soporteExistente.get();
            soporte.setNombre(soporteActualizado.getNombre());
            soporte.setApellido(soporteActualizado.getApellido());
            soporte.setCorreo(soporteActualizado.getCorreo());
            soporte.setRun(soporteActualizado.getRun());
            soporte.setFechaNacimiento(soporteActualizado.getFechaNacimiento());

            SoporteModel actualizado = soporteService.guardar(soporte);
            return ResponseEntity.ok(assembler.toModel(actualizado));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar soporte", description = "Eliminar un soporte por su ID")
    public ResponseEntity<Void> eliminarSoporte(@PathVariable Long id) {
        if (soporteService.existePorId(id)) {
            soporteService.eliminarPorId(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/cliente/{clienteId}")
    @Operation(summary = "Mostrar un cliente", description = "Mostrar un cliente por su ID")
    public ResponseEntity<ClienteDTO> obtenerCliente(@PathVariable Integer clienteId) {
        ClienteDTO cliente = soporteService.obtenerClientePorId(clienteId);
        if (cliente != null) {
            return ResponseEntity.ok(cliente);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
