package com.Edutechsoporte.soporte.hateoas;

import com.Edutechsoporte.soporte.Controller.SoporteController;
import com.Edutechsoporte.soporte.Model.SoporteModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class SoporteModelAssembler implements RepresentationModelAssembler<SoporteModel, EntityModel<SoporteModel>> {

    @Override
    public EntityModel<SoporteModel> toModel(SoporteModel soporte) {
        return EntityModel.of(soporte,
                linkTo(methodOn(SoporteController.class).obtener(soporte.getId())).withSelfRel(),
                linkTo(methodOn(SoporteController.class).listar()).withRel("soportes"));
    }
    
}
