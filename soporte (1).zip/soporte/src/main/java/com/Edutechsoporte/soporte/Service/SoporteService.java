package com.Edutechsoporte.soporte.Service;


import com.Edutechsoporte.soporte.Model.SoporteModel;
import com.Edutechsoporte.soporte.Repository.SoporteRepository;
import com.Edutechsoporte.soporte.Dto.ClienteDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.*;

@Service
public class SoporteService {

    private final SoporteRepository soporteRepository;
    private final RestTemplate restTemplate;

    private final String CLIENTE_URL = "http://localhost:8080/api/v1/clientes";

    @Autowired
    public SoporteService(SoporteRepository soporteRepository, RestTemplate restTemplate){
        this.soporteRepository = soporteRepository;
        this.restTemplate = restTemplate;
    }

    public SoporteModel guardar(SoporteModel soporte){
        return soporteRepository.save(soporte);
    }

    public Optional<SoporteModel> obtenerPorId(Long id){
        return soporteRepository.findById(id);
    }

    public List<SoporteModel> listar() {
        return soporteRepository.findAll();
    }

    public boolean existePorId(Long id) {
        return soporteRepository.existsById(id);
    }

    public void eliminarPorId(Long id) {
        soporteRepository.deleteById(id);
    }

    public ClienteDTO obtenerClientePorId(Integer clienteId){
        String url = CLIENTE_URL + "/" + clienteId;
        try {
            return restTemplate.getForObject(url, ClienteDTO.class);
        } catch (Exception e) {
            return null;
        }
    }
}

